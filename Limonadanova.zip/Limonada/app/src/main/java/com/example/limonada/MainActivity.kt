package com.example.limonada


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.limonada.ui.theme.ArtSpaceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArtSpaceTheme {
                ArtSpaceApp()
            }
        }
    }
}

enum class ArtSpaceState {
    Foto1,
    Foto2,
    Foto3,
    Foto4
}

@Composable
fun ArtSpaceApp() {
    var currentStep by remember { mutableStateOf(ArtSpaceState.Foto1) }
    var squeezeCount by remember { mutableStateOf(2) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            when (currentStep) {

                ArtSpaceState.Foto1 -> {
                    Image(
                        painter = painterResource(R.drawable.imagen2),
                        contentDescription = stringResource(R.string.Chimpance),
                                modifier = Modifier
                                    .shadow(8.dp)
                                    .padding(8.dp)

                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = stringResource(R.string.Chimpance),
                        fontSize = 24.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp),
                        textAlign = TextAlign.Left
                    )
                    Spacer(modifier = Modifier.height(15.dp))
                    Text(
                        text = stringResource(R.string.ChimpanceDescripcion),
                        fontSize = 16.sp,
                        modifier = Modifier.background(
                            color = Color.LightGray
                        )


                    )

                }

                ArtSpaceState.Foto2 -> {
                    Image(
                        painter = painterResource(R.drawable.peru_machu_picchu_lhama_1500x1000),
                        contentDescription = stringResource(R.string.PeruDescripcion),
                            modifier = Modifier
                                .shadow(8.dp)
                                .padding(8.dp)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = stringResource(R.string.Peru),
                        fontSize = 24.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp),
                        textAlign = TextAlign.Left
                    )
                    Spacer(modifier = Modifier.height(15.dp))
                    Text(
                        text = stringResource(R.string.PeruDescripcion),
                        fontSize = 16.sp,
                        modifier = Modifier.background(
                            color = Color.LightGray
                        )
                    )

                }

                ArtSpaceState.Foto3 -> {
                    Image(
                        painter = painterResource(R.drawable.b68a245350cc3df085f1345076454505),
                        contentDescription = stringResource(R.string.SantiagodeChileDescripcion),
                        modifier = Modifier
                            .shadow(8.dp)
                            .padding(8.dp)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = stringResource(R.string.SantiagodeChile),
                        fontSize = 24.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp),
                        textAlign = TextAlign.Left
                    )
                    Spacer(modifier = Modifier.height(15.dp))
                    Text(
                        text = stringResource(R.string.SantiagodeChileDescripcion),
                        fontSize = 16.sp,
                        modifier = Modifier.background(
                            color = Color.LightGray
                        )
                    )

                }

                ArtSpaceState.Foto4 -> {
                    Image(
                        painter = painterResource(R.drawable.potosi_unesco_in_bolivia_the_worlds_highest_city_4070m__potosi_is_set_against_the_backdrop_of_a_ranbow_colored_mountain_cerro_rico__cityscape_cerro_rico_and_roftop_view_from_cathedral),
                        contentDescription = stringResource(R.string.BoliviaDescripcion),
                        modifier = Modifier
                            .shadow(8.dp)
                            .padding(8.dp)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    Text(
                        text = stringResource(R.string.Bolivia),
                        fontSize = 24.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp),
                        textAlign = TextAlign.Left
                    )
                    Spacer(modifier = Modifier.height(15.dp))
                    Text(
                        text = stringResource(R.string.BoliviaDescripcion),
                        fontSize = 16.sp,
                        modifier = Modifier.background(
                            color = Color.LightGray
                        )
                    )

                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { currentStep = previousStep(currentStep) },
                    enabled = currentStep != ArtSpaceState.Foto1
                ) {
                    Text("Volver")
                }
                Button(
                    onClick = { currentStep = nextStep(currentStep) },
                    enabled = currentStep != ArtSpaceState.Foto4
                ) {
                    Text("Avanzar")
                }
            }
        }
    }
}



fun previousStep(currentStep: ArtSpaceState): ArtSpaceState {
    return when (currentStep) {
        ArtSpaceState.Foto1 -> ArtSpaceState.Foto4
        ArtSpaceState.Foto2 -> ArtSpaceState.Foto1
        ArtSpaceState.Foto3 -> ArtSpaceState.Foto2
        ArtSpaceState.Foto4 -> ArtSpaceState.Foto3
    }
}


fun nextStep(currentStep: ArtSpaceState): ArtSpaceState {
    return when (currentStep) {
        ArtSpaceState.Foto1 -> ArtSpaceState.Foto2
        ArtSpaceState.Foto2 -> ArtSpaceState.Foto3
        ArtSpaceState.Foto3 -> ArtSpaceState.Foto4
        ArtSpaceState.Foto4 -> ArtSpaceState.Foto1


    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ArtSpaceTheme {
        ArtSpaceApp()
    }
}
