package com.example.artspace

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.artspace.ui.theme.ArtSpaceTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ArtSpaceTheme {
                    ArtSpaceApp()
                }
            }
        }
    }
enum class ArtSpaceStep{
    Foto1,
    Foto2,
    Foto3,
    Foto4
}

@Composable
fun ArtSpaceApp(){
var currentStep by remember { mutableStateOf(ArtSpaceStep.Foto1) }
    var squeezeCount by remember { mutableStateOf(0) }


    Surface(modifier=Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background) {
        when(currentStep){
            ArtSpaceStep.Foto1->{
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ){
                    Text(text = stringResource(R.string.Foto1))
                    Spacer(modifier = Modifier.height(32.dp))
                    Image(
                        painter = painterResource(R.drawable.potosi_unesco_in_bolivia_the_worlds_highest_city_4070m__potosi_is_set_against_the_backdrop_of_a_ranbow_colored_mountain_cerro_rico__cityscape_cerro_rico_and_roftop_view_from_cathedral),
                        contentDescription = stringResource(R.string.Foto1_Descripcion),
                        modifier = Modifier
                            .wrapContentSize()
                            .clickable {
                                currentStep = ArtSpaceStep.Foto2

                            }
                    )

                }
            }
            ArtSpaceStep.Foto2->{
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ){

                    Text(text = stringResource(R.string.Foto2))
                    Spacer(modifier = Modifier.height(32.dp))
                    Image(
                        painter = painterResource(R.drawable.imagen2),
                        contentDescription = stringResource(R.string.Foto2_Descripcion),
                        modifier = Modifier
                            .wrapContentSize()
                            .clickable {
                                currentStep = ArtSpaceStep.Foto3

                            }
                    )
                }
            }
            ArtSpaceStep.Foto3->{
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ){
                    Text(text = stringResource(R.string.Foto3))
                    Spacer(modifier = Modifier.height(32.dp))
                    Image(
                        painter = painterResource(R.drawable.b68a245350cc3df085f1345076454505),
                        contentDescription = stringResource(R.string.Foto3_Descripcion),
                        modifier = Modifier
                            .wrapContentSize()
                            .clickable {
                                currentStep = ArtSpaceStep.Foto4

                            }
                    )

                }
            }
            ArtSpaceStep.Foto4->{
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ){
                    Text(text = stringResource(R.string.Foto4))
                    Spacer(modifier = Modifier.height(32.dp))
                    Image(
                        painter = painterResource(R.drawable.peru_machu_picchu_lhama_1500x1000),
                        contentDescription = stringResource(R.string.Foto4_Descripcion),
                        modifier = Modifier
                            .wrapContentSize()
                            .clickable {
                                currentStep = ArtSpaceStep.Foto4

                            }
                    )

                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ArtSpaceTheme {
        ArtSpaceApp()
    }
}